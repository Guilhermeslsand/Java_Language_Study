package br.ufc.poo.clientes.excecoes;
import java.lang.Exception;

public class DIException extends Exception{
	private static final long serialVersionUID = 1L;

	public DIException(String mensagem){super(mensagem);
	}
}
