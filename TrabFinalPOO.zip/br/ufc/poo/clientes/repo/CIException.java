package br.ufc.poo.clientes.repo;

public class CIException extends Exception {
	private static final long serialVersionUID = 1L;

	public CIException(String mensagem){super(mensagem);
	}
}
